# Control Cabify

Proyecto Android para registrar tus jornadas de Cabify.

Incluye:
- Fecha de cada jornada.
- Ingreso inicial y final.
- Saldo automático.
- Porcentaje configurable, por defecto 35%.
- Historial guardado en el teléfono.
- Resumen de días, saldo total y monto calculado para ti.

Este proyecto está pensado para construirse mediante GitHub Actions.
