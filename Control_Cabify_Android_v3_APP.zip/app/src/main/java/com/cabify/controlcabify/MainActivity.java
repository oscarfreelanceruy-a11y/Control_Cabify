package com.cabify.controlcabify;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private EditText dateInput, startInput, endInput, percentInput;
    private TextView preview, summary, history;
    private DbHelper db;
    private final NumberFormat money = NumberFormat.getCurrencyInstance(new Locale("es", "UY"));
    private final SimpleDateFormat dateFmt = new SimpleDateFormat("dd/MM/yyyy", new Locale("es", "UY"));
    private final SimpleDateFormat dbFmt = new SimpleDateFormat("yyyy-MM-dd", Locale.US);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        db = new DbHelper(this);
        buildUi();
        loadSettings();
        dateInput.setText(dateFmt.format(new Date()));
        updatePreview();
        refreshData();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(18), dp(16), dp(24));
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("CONTROL CABIFY");
        title.setTextSize(26);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, lp(-1, -2, 0));

        TextView subtitle = text("Control diario de ingresos, saldo y porcentaje. Los datos quedan guardados en el teléfono.");
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle, lp(-1, -2, 0));

        root.addView(section("NUEVA JORNADA"));
        dateInput = field("Fecha (dd/mm/aaaa)", false);
        dateInput.setOnClickListener(v -> showDatePicker());
        root.addView(dateInput, lp(-1, -2, 0));

        startInput = field("Ingreso inicial del día", true);
        endInput = field("Ingreso final del día", true);
        root.addView(startInput, lp(-1, -2, 0));
        root.addView(endInput, lp(-1, -2, 0));

        percentInput = field("Porcentaje para ti (%)", true);
        percentInput.setText("35");
        root.addView(percentInput, lp(-1, -2, 0));
        percentInput.setOnFocusChangeListener((v, hasFocus) -> { if (!hasFocus) { saveSettings(); updatePreview(); } });

        Button calc = button("CALCULAR");
        calc.setOnClickListener(v -> updatePreview());
        root.addView(calc, lp(-1, -2, 0));

        preview = text("");
        preview.setTextSize(18);
        preview.setPadding(dp(12), dp(12), dp(12), dp(12));
        root.addView(preview, lp(-1, -2, 0));

        Button save = button("GUARDAR JORNADA");
        save.setOnClickListener(v -> saveEntry());
        root.addView(save, lp(-1, -2, 0));

        Button clearFields = button("LIMPIAR CAMPOS");
        clearFields.setOnClickListener(v -> clearEntryFields());
        root.addView(clearFields, lp(-1, -2, 0));

        root.addView(section("RESUMEN"));
        summary = text("");
        summary.setTextSize(17);
        root.addView(summary, lp(-1, -2, 0));

        root.addView(section("HISTORIAL"));
        history = text("");
        history.setTextSize(15);
        root.addView(history, lp(-1, -2, 0));

        Button deleteAll = button("BORRAR TODO EL HISTORIAL");
        deleteAll.setOnClickListener(v -> {
            db.getWritableDatabase().delete("days", null, null);
            refreshData();
            Toast.makeText(this, "Historial borrado", Toast.LENGTH_SHORT).show();
        });
        root.addView(deleteAll, lp(-1, -2, 0));

        Button savePercent = button("GUARDAR PORCENTAJE");
        savePercent.setOnClickListener(v -> { saveSettings(); updatePreview(); Toast.makeText(this, "Porcentaje guardado", Toast.LENGTH_SHORT).show(); });
        root.addView(savePercent, lp(-1, -2, 0));

        setContentView(scroll);
    }

    private void showDatePicker() {
        Calendar c = Calendar.getInstance();
        try { c.setTime(dateFmt.parse(dateInput.getText().toString())); } catch (Exception ignored) {}
        DatePickerDialog d = new DatePickerDialog(this, (view, y, m, day) -> {
            Calendar selected = Calendar.getInstance();
            selected.set(y, m, day);
            dateInput.setText(dateFmt.format(selected.getTime()));
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
        d.show();
    }

    private void updatePreview() {
        double start = number(startInput == null ? "" : startInput.getText().toString());
        double end = number(endInput == null ? "" : endInput.getText().toString());
        double pct = percentage();
        double balance = end - start;
        double mine = balance * pct / 100.0;
        preview.setText("Saldo de la jornada: " + money.format(balance) + "\n" +
                "Tu " + trimPct(pct) + "%: " + money.format(mine));
    }

    private void saveEntry() {
        String dateDisplay = dateInput.getText().toString().trim();
        if (dateDisplay.isEmpty()) { toast("Indica la fecha"); return; }
        double start = number(startInput.getText().toString());
        double end = number(endInput.getText().toString());
        if (end < start) { toast("El ingreso final no puede ser menor que el inicial"); return; }
        double pct = percentage();
        String dateKey;
        try { dateKey = dbFmt.format(dateFmt.parse(dateDisplay)); }
        catch (Exception e) { toast("Fecha inválida"); return; }

        SQLiteDatabase database = db.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("date_key", dateKey);
        values.put("start_income", start);
        values.put("end_income", end);
        values.put("percent", pct);
        database.insertWithOnConflict("days", null, values, SQLiteDatabase.CONFLICT_REPLACE);
        saveSettings();
        refreshData();
        Toast.makeText(this, "Jornada guardada", Toast.LENGTH_SHORT).show();
    }

    private void refreshData() {
        double totalBalance = 0, totalMine = 0;
        int count = 0;
        StringBuilder h = new StringBuilder();
        Cursor c = db.getReadableDatabase().rawQuery("SELECT date_key,start_income,end_income,percent FROM days ORDER BY date_key DESC", null);
        while (c.moveToNext()) {
            String date = c.getString(0);
            double start = c.getDouble(1), end = c.getDouble(2), pct = c.getDouble(3);
            double balance = end - start;
            double mine = balance * pct / 100.0;
            totalBalance += balance;
            totalMine += mine;
            count++;
            h.append(displayDate(date)).append("  |  Saldo ").append(money.format(balance))
                    .append("  |  ").append(trimPct(pct)).append("% = ").append(money.format(mine)).append("\n");
        }
        c.close();
        summary.setText("Días registrados: " + count + "\nSaldo total: " + money.format(totalBalance) +
                "\nTotal para ti: " + money.format(totalMine));
        history.setText(count == 0 ? "Todavía no hay jornadas guardadas." : h.toString());
    }

    private String displayDate(String key) {
        try { return dateFmt.format(dbFmt.parse(key)); } catch (Exception e) { return key; }
    }

    private void clearEntryFields() {
        startInput.setText("");
        endInput.setText("");
        dateInput.setText(dateFmt.format(new Date()));
        updatePreview();
    }

    private double percentage() {
        double p = number(percentInput == null ? "35" : percentInput.getText().toString());
        if (p <= 0 || p > 100) p = 35;
        return p;
    }

    private void loadSettings() {
        percentInput.setText(String.valueOf(getPreferences(MODE_PRIVATE).getFloat("pct", 35f)));
    }

    private void saveSettings() {
        getPreferences(MODE_PRIVATE).edit().putFloat("pct", (float) percentage()).apply();
    }

    private double number(String s) {
        if (s == null) return 0;
        s = s.trim().replace("$", "").replace("UYU", "").replace(" ", "");
        if (s.contains(",") && s.contains(".")) {
            s = s.replace(".", "").replace(",", ".");
        } else if (s.contains(",")) {
            s = s.replace(",", ".");
        }
        try { return Double.parseDouble(s); } catch (Exception e) { return 0; }
    }

    private String trimPct(double p) {
        return (p == Math.rint(p)) ? String.valueOf((int)p) : String.format(Locale.US, "%.2f", p);
    }

    private TextView section(String s) {
        TextView t = text(s);
        t.setTextSize(19);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(0, dp(22), 0, dp(8));
        return t;
    }

    private TextView text(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        return t;
    }

    private EditText field(String hint, boolean number) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextSize(16);
        e.setSingleLine(true);
        if (number) e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        else e.setInputType(android.text.InputType.TYPE_CLASS_DATETIME);
        e.setPadding(dp(12), dp(8), dp(12), dp(8));
        return e;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        return b;
    }

    private LinearLayout.LayoutParams lp(int w, int h, int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.topMargin = dp(top);
        return p;
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    private static class DbHelper extends SQLiteOpenHelper {
        DbHelper(Context c) { super(c, "cabify.db", null, 1); }
        @Override public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE days (date_key TEXT PRIMARY KEY, start_income REAL NOT NULL, end_income REAL NOT NULL, percent REAL NOT NULL)");
        }
        @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { }
    }
}
