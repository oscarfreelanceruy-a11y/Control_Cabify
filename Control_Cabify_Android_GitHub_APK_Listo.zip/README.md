# Control Cabify Android v2

Actualización completa:
- Porcentaje configurable (predeterminado 35%).
- Cada jornada guarda su propio porcentaje histórico.
- Objetivo diario configurable.
- Ingreso inicial/final y facturación.
- Combustible y otros gastos.
- Ganancia neta.
- Kilómetros y horas.
- Ganancia neta por hora en la vista previa.
- Historial, edición y eliminación.
- Resumen semanal de 7 días y mensual.
- Datos locales en el teléfono.

Para generar el APK: abrir el proyecto en Android Studio y usar Build > Build APK(s).
