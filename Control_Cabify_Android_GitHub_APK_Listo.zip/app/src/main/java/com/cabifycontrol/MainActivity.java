package com.cabifycontrol;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.text.*;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    SharedPreferences prefs;
    ArrayList<Day> days=new ArrayList<>();
    final SimpleDateFormat DF=new SimpleDateFormat("dd/MM/yyyy",Locale.getDefault());

    static class Day {
        String date,note; double start,end,fuel,other,km,hours,pct;
        Day(String d,double s,double e,double fu,double o,double k,double h,double p,String n){
            date=d;start=s;end=e;fuel=fu;other=o;km=k;hours=h;pct=p;note=n;
        }
        double gross(){return end-start;}
        double share(){return gross()*pct/100.0;}
        double net(){return gross()-fuel-other;}
        JSONObject json()throws Exception{
            JSONObject x=new JSONObject(); x.put("date",date);x.put("start",start);x.put("end",end);
            x.put("fuel",fuel);x.put("other",other);x.put("km",km);x.put("hours",hours);x.put("pct",pct);x.put("note",note);return x;
        }
        static Day from(JSONObject x)throws Exception{
            return new Day(x.getString("date"),x.getDouble("start"),x.getDouble("end"),
            x.optDouble("fuel",0),x.optDouble("other",0),x.optDouble("km",0),x.optDouble("hours",0),
            x.optDouble("pct",35),x.optString("note",""));
        }
    }

    public void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences("cabify",MODE_PRIVATE);load();home();}

    TextView tv(String s,int z,boolean bold){
        TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(Color.DKGRAY);t.setPadding(18,12,18,12);
        if(bold)t.setTypeface(null,1);return t;
    }
    Button btn(String s){Button b=new Button(this);b.setText(s);return b;}
    void base(String title){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        TextView bar=tv(title,21,true);bar.setTextColor(Color.WHITE);bar.setBackgroundColor(Color.rgb(21,101,192));
        root.addView(bar,new LinearLayout.LayoutParams(-1,64));
        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv=new ScrollView(this);sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=new LinearLayout(this);
        Button a=btn("Inicio"),b=btn("Historial"),c=btn("Resumen"),d=btn("⚙ Config.");
        nav.addView(a,new LinearLayout.LayoutParams(0,60,1));nav.addView(b,new LinearLayout.LayoutParams(0,60,1));
        nav.addView(c,new LinearLayout.LayoutParams(0,60,1));nav.addView(d,new LinearLayout.LayoutParams(0,60,1));
        a.setOnClickListener(v->home());b.setOnClickListener(v->history());c.setOnClickListener(v->summary());d.setOnClickListener(v->settings());
        root.addView(nav);setContentView(root);
    }
    double configuredPct(){return prefs.getFloat("pct",35f);}
    double target(){return prefs.getFloat("target",6000f);}
    String money(double x){return String.format(Locale.getDefault(),"$ %.2f",x);}
    double val(EditText e){try{return Double.parseDouble(e.getText().toString().replace(",","."));}catch(Exception e2){return 0;}}

    void home(){
        base("Control Cabify");
        double g=0,n=0,s=0;for(Day d:days){g+=d.gross();n+=d.net();s+=d.share();}
        content.addView(tv("Resumen general",20,true));
        content.addView(tv("Facturación acumulada: "+money(g)+"\nNeto después de gastos: "+money(n)+
        "\nPorcentaje actual: "+configuredPct()+"%\nTotal según porcentaje: "+money(s)+"\nJornadas: "+days.size(),17,false));
        Button add=btn("＋ NUEVA JORNADA");content.addView(add);add.setOnClickListener(v->edit(null));
        Button set=btn("Cambiar porcentaje / objetivos");content.addView(set);set.setOnClickListener(v->settings());
        content.addView(tv("Últimas jornadas",19,true));
        ArrayList<Day> q=new ArrayList<>(days);Collections.reverse(q);int i=0;for(Day d:q){if(i++>=5)break;content.addView(card(d));}
    }

    View card(Day d){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(10,8,10,8);box.setBackgroundColor(Color.rgb(245,247,250));
        box.addView(tv(d.date+"  |  Facturado "+money(d.gross()),17,true));
        box.addView(tv("35/porcentaje: "+fmt(d.pct)+"% = "+money(d.share())+
        "\nGastos: "+money(d.fuel+d.other)+"  |  Neto: "+money(d.net())+
        "\nKm: "+fmt(d.km)+"  |  Horas: "+fmt(d.hours)+(d.note.isEmpty()?"":"\n"+d.note),15,false));
        LinearLayout ac=new LinearLayout(this);Button e=btn("Editar"),x=btn("Eliminar");
        ac.addView(e,new LinearLayout.LayoutParams(0,55,1));ac.addView(x,new LinearLayout.LayoutParams(0,55,1));box.addView(ac);
        e.setOnClickListener(v->edit(d));
        x.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Eliminar jornada").setMessage("¿Eliminar "+d.date+"?")
        .setNegativeButton("Cancelar",null).setPositiveButton("Eliminar",(a,b)->{days.remove(d);save();history();}).show());
        return box;
    }

    String fmt(double x){return String.format(Locale.getDefault(),"%.2f",x);}

    EditText input(String hint,double v){
        EditText e=new EditText(this);e.setHint(hint);e.setInputType(2|8192);if(v!=0)e.setText(fmt(v));return e;
    }

    void edit(Day old){
        LinearLayout f=new LinearLayout(this);f.setOrientation(LinearLayout.VERTICAL);f.setPadding(20,5,20,5);
        EditText date=input("Fecha dd/MM/yyyy",0);date.setInputType(1);date.setText(old==null?DF.format(new Date()):old.date);
        EditText start=input("Ingreso inicial",old==null?0:old.start),end=input("Ingreso final",old==null?0:old.end);
        EditText fuel=input("Gasto combustible",old==null?0:old.fuel),other=input("Otros gastos",old==null?0:old.other);
        EditText km=input("Kilómetros recorridos",old==null?0:old.km),hours=input("Horas trabajadas",old==null?0:old.hours);
        EditText pct=input("Porcentaje de ganancia",old==null?configuredPct():old.pct);
        EditText note=input("Observaciones",0);note.setText(old==null?"":old.note);
        TextView calc=tv("Vista previa",17,true);
        f.addView(date);f.addView(start);f.addView(end);f.addView(fuel);f.addView(other);f.addView(km);f.addView(hours);f.addView(pct);f.addView(note);f.addView(calc);
        View.OnFocusChangeListener l=(v,h)->{
            double gross=val(end)-val(start), p=val(pct);
            calc.setText("Facturación: "+money(gross)+"\nPorcentaje: "+money(gross*p/100)+"\nGastos: "+money(val(fuel)+val(other))+
            "\nNeto: "+money(gross-val(fuel)-val(other))+"\nPor hora: "+money(val(hours)>0?(gross-val(fuel)-val(other))/val(hours):0));
        };
        start.setOnFocusChangeListener(l);end.setOnFocusChangeListener(l);fuel.setOnFocusChangeListener(l);other.setOnFocusChangeListener(l);hours.setOnFocusChangeListener(l);pct.setOnFocusChangeListener(l);
        new AlertDialog.Builder(this).setTitle(old==null?"Nueva jornada":"Editar jornada").setView(f)
        .setNegativeButton("Cancelar",null).setPositiveButton("Guardar",(a,b)->{
            Day nd=new Day(date.getText().toString(),val(start),val(end),val(fuel),val(other),val(km),val(hours),val(pct),note.getText().toString());
            if(old==null)days.add(nd);else days.set(days.indexOf(old),nd);save();home();
        }).show();
    }

    void history(){base("Historial");if(days.isEmpty()){content.addView(tv("No hay jornadas registradas.",18,false));return;}
        ArrayList<Day> q=new ArrayList<>(days);Collections.sort(q,(a,b)->b.date.compareTo(a.date));for(Day d:q)content.addView(card(d));}

    void summary(){
        base("Resumen semanal y mensual");
        EditText date=input("Fecha inicial dd/MM/yyyy",0);Calendar c=Calendar.getInstance();c.set(Calendar.DAY_OF_WEEK,Calendar.MONDAY);date.setText(DF.format(c.getTime()));
        content.addView(tv("Semana de 7 días",19,true));content.addView(date);Button calc=btn("CALCULAR SEMANA");content.addView(calc);TextView out=tv("",17,false);content.addView(out);
        calc.setOnClickListener(v->{
            try{Date base=DF.parse(date.getText().toString());Calendar z=Calendar.getInstance();z.setTime(base);
                double g=0,n=0,p=0;StringBuilder s=new StringBuilder();
                for(int i=0;i<7;i++){String ds=DF.format(z.getTime());for(Day d:days)if(d.date.equals(ds)){g+=d.gross();n+=d.net();p+=d.share();s.append(ds+"  "+money(d.gross())+"  | "+fmt(d.pct())+"% = "+money(d.share())+"  | neto "+money(d.net())+"\\n");}z.add(Calendar.DAY_OF_MONTH,1);}
                out.setText("FACTURACIÓN: "+money(g)+"\nNETO: "+money(n)+"\nPORCENTAJE: "+money(p)+"\n\n"+s);
            }catch(Exception e){out.setText("Fecha inválida.");}
        });
        Button mon=btn("RESUMEN DEL MES ACTUAL");content.addView(mon);mon.setOnClickListener(v->{
            Calendar now=Calendar.getInstance();int m=now.get(Calendar.MONTH),y=now.get(Calendar.YEAR);double g=0,n=0,p=0;int count=0;
            for(Day d:days)try{Calendar q=Calendar.getInstance();q.setTime(DF.parse(d.date));if(q.get(Calendar.MONTH)==m&&q.get(Calendar.YEAR)==y){g+=d.gross();n+=d.net();p+=d.share();count++;}}catch(Exception e){}
            out.setText("MES ACTUAL\\n\\nFacturación: "+money(g)+"\\nNeto: "+money(n)+"\\nPorcentaje: "+money(p)+"\\nDías: "+count);
        });
    }

    void settings(){
        base("Configuración");
        content.addView(tv("Porcentaje de ganancia",19,true));
        EditText pct=input("Ejemplo: 35",configuredPct());content.addView(pct);
        content.addView(tv("Este valor se usará como predeterminado para nuevas jornadas. Las jornadas anteriores conservan su porcentaje.",15,false));
        content.addView(tv("Objetivo diario de facturación",19,true));
        EditText tar=input("Ejemplo: 6000",target());content.addView(tar);
        Button save=btn("GUARDAR CONFIGURACIÓN");content.addView(save);
        save.setOnClickListener(v->{double p=val(pct),t=val(tar);if(p<0||p>100){Toast.makeText(this,"El porcentaje debe estar entre 0 y 100.",Toast.LENGTH_SHORT).show();return;}
            prefs.edit().putFloat("pct",(float)p).putFloat("target",(float)t).apply();Toast.makeText(this,"Configuración guardada.",Toast.LENGTH_SHORT).show();home();});
    }

    void save(){JSONArray a=new JSONArray();try{for(Day d:days)a.put(d.json());prefs.edit().putString("days",a.toString()).apply();}catch(Exception e){}}
    void load(){try{JSONArray a=new JSONArray(prefs.getString("days","[]"));for(int i=0;i<a.length();i++)days.add(Day.from(a.getJSONObject(i)));}catch(Exception e){}}
}