# Control Cabify Android

Proyecto Android de Control Cabify.

## Generar la APK con GitHub desde el teléfono

1. Crea o abre un repositorio en GitHub.
2. Sube TODOS los archivos y carpetas de este ZIP.
3. Entra en la pestaña **Actions**.
4. Selecciona **Generar APK**.
5. Pulsa **Run workflow**.
6. Espera a que termine el proceso con un ✓ verde.
7. Entra en la ejecución terminada y baja hasta **Artifacts**.
8. Descarga **Control-Cabify-APK**.
9. Dentro encontrarás `app-debug.apk`.

No necesitas Android Studio para este método.
